const router = require("express").Router();
const {
  createTask,
  getTasks,
  updateStatus,
  deleteTask,
} = require("../controllers/taskController");

const auth = require("../middleware/authMiddleware");

router.post("/", auth, createTask);
router.get("/", auth, getTasks);
router.put("/status", auth, updateStatus);
router.delete("/:id", auth, deleteTask);

module.exports = router;
