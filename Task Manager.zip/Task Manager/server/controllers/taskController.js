const db = require("../config/db");

// CREATE TASK (Admin)
exports.createTask = (req, res) => {
  const { title, description, priority, deadline, assigned_to } = req.body;

  db.query(
    "INSERT INTO tasks (title,description,priority,deadline,assigned_to) VALUES (?,?,?,?,?)",
    [title, description, priority, deadline, assigned_to],
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "Task created" });
    },
  );
};

// GET TASKS
exports.getTasks = (req, res) => {
  const userId = req.user.id;
  const role = req.user.role;

  if (role === "admin") {
    db.query("SELECT * FROM tasks", (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result);
    });
  } else {
    db.query(
      "SELECT * FROM tasks WHERE assigned_to=?",
      [userId],
      (err, result) => {
        if (err) return res.status(500).json(err);
        res.json(result);
      },
    );
  }
};

// UPDATE STATUS
exports.updateStatus = (req, res) => {
  const { id, status } = req.body;

  db.query(
    "UPDATE tasks SET status=? WHERE id=?",
    [status, id],
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "Status updated" });
    },
  );
};

// DELETE TASK (Admin)
exports.deleteTask = (req, res) => {
  const id = req.params.id;

  db.query("DELETE FROM tasks WHERE id=?", [id], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "Task deleted" });
  });
};
