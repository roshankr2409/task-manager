const router = require("express").Router();

const {
  createTask,
  getTasks,
  updateStatus,
  deleteTask,
  updateTask,
  getStats,
  getMyStats,
} = require("../controllers/taskController");

const auth = require("../middleware/authMiddleware");

// ===== CREATE TASK (ADMIN) =====
router.post("/", auth, createTask);

// ===== GET TASKS (ROLE BASED) =====
router.get("/", auth, getTasks);

// ===== UPDATE STATUS (EMPLOYEE/ADMIN) =====
router.put("/status", auth, updateStatus);

// ===== UPDATE FULL TASK (ADMIN EDIT) =====
router.put("/", auth, updateTask);

// ===== DELETE TASK (ADMIN) =====
router.delete("/:id", auth, deleteTask);

// ===== ADMIN DASHBOARD STATS =====
router.get("/stats", auth, getStats);

// ===== EMPLOYEE DASHBOARD STATS =====
router.get("/my-stats", auth, getMyStats);

module.exports = router;
