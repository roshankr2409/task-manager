function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  fetch("http://localhost:5000/api/auth/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  })
    .then((res) => res.json())
    .then((data) => {
      // If login failed
      if (data.msg) {
        alert(data.msg);
        return;
      }

      // Save token
      localStorage.setItem("token", data.token);

      // Redirect based on role
      if (data.user.role === "admin") {
        window.location.href = "admin.html";
      } else {
        window.location.href = "employee.html";
      }
    })
    .catch((err) => {
      console.log(err);
      alert("Login failed");
    });
}
