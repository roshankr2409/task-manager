const db = require("../config/db");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    const hashed = await bcrypt.hash(password, 10);

    db.query(
      "INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)",
      [name, email, hashed, role || "employee"],
      (err, result) => {
        if (err) return res.status(500).json(err);
        res.json({ message: "User registered" });
      },
    );
  } catch (err) {
    res.status(500).json(err);
  }
};

exports.login = (req, res) => {
  const { email, password } = req.body;

  db.query(
    "SELECT * FROM users WHERE email=?",
    [email],
    async (err, result) => {
      if (err) return res.status(500).json(err);
      if (result.length === 0)
        return res.status(401).json({ msg: "User not found" });

      const user = result[0];

      const match = await bcrypt.compare(password, user.password);
      if (!match) return res.status(401).json({ msg: "Wrong password" });

      const token = jwt.sign(
        { id: user.id, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: "1d" },
      );

      res.json({ token, user });
    },
  );
};
