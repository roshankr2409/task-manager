const db = require("../config/db");

// ================= CREATE TASK =================
exports.createTask = (req, res) => {
  const { title, description, priority, deadline, assigned_to } = req.body;

  db.query(
    "INSERT INTO tasks (title, description, priority, deadline, assigned_to) VALUES (?,?,?,?,?)",
    [title, description, priority, deadline, assigned_to],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "Task created successfully" });
    },
  );
};

// ================= GET TASKS =================
exports.getTasks = (req, res) => {
  const userId = req.user.id;
  const role = req.user.role;

  const query =
    role === "admin"
      ? "SELECT * FROM tasks"
      : "SELECT * FROM tasks WHERE assigned_to=?";

  db.query(query, role === "admin" ? [] : [userId], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result);
  });
};

// ================= UPDATE STATUS =================
exports.updateStatus = (req, res) => {
  const { id, status } = req.body;

  db.query("UPDATE tasks SET status=? WHERE id=?", [status, id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "Status updated successfully" });
  });
};

// ================= UPDATE FULL TASK (ADMIN EDIT) =================
exports.updateTask = (req, res) => {
  const { id, title, description, priority, deadline, assigned_to, status } =
    req.body;

  db.query(
    `UPDATE tasks 
     SET title=?, description=?, priority=?, deadline=?, assigned_to=?, status=?
     WHERE id=?`,
    [title, description, priority, deadline, assigned_to, status, id],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "Task updated successfully" });
    },
  );
};

// ================= DELETE TASK =================
exports.deleteTask = (req, res) => {
  const id = req.params.id;

  db.query("DELETE FROM tasks WHERE id=?", [id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "Task deleted successfully" });
  });
};

// ================= ADMIN DASHBOARD STATS =================
exports.getStats = (req, res) => {
  db.query(
    `
    SELECT 
      COUNT(*) AS totalTasks,
      COALESCE(SUM(status='Completed'),0) AS completedTasks,
      COALESCE(SUM(status='Pending'),0) AS pendingTasks
    FROM tasks
    `,
    (err, taskStats) => {
      if (err) return res.status(500).json(err);

      db.query("SELECT COUNT(*) AS totalUsers FROM users", (err, userStats) => {
        if (err) return res.status(500).json(err);

        res.json({
          totalTasks: taskStats[0].totalTasks,
          completedTasks: taskStats[0].completedTasks,
          pendingTasks: taskStats[0].pendingTasks,
          totalUsers: userStats[0].totalUsers,
        });
      });
    },
  );
};

// ================= EMPLOYEE DASHBOARD STATS =================
exports.getMyStats = (req, res) => {
  const userId = req.user.id;

  db.query(
    `
    SELECT 
      COUNT(*) AS myTasks,
      COALESCE(SUM(status='Completed'),0) AS completedTasks,
      COALESCE(SUM(status='Pending'),0) AS pendingTasks
    FROM tasks
    WHERE assigned_to=?
    `,
    [userId],
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result[0]);
    },
  );
};
